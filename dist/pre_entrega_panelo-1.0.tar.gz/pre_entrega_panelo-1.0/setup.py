from setuptools import setup

setup(
    name = "pre_entrega_panelo",
    version="1.0",
    description="la segunda pre entrega ",
    author="mariano panelo",
    author_email="elmanu_panelo@hotmail.com",

    packages=["modulo1","modulo2"]
)

